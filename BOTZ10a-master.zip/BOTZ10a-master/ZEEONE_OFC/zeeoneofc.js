/*

   GK ADA APA² KAWAN
   
   SUB AJA ZEEONE OFC
   
*/
