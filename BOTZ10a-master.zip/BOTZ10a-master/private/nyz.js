  /*
	* HAI NAMAKU NAYLA
	* YAH DISINI AKU SEBAGAI PEMULA 
	* MAU MENCOBA MEMBUAT BOT SENDIRI
	* YANG PASTINYA PASTI BANYAK YG
	* BAKAL MELANGGAR DISINI
	* OKE TERIMA KASIH
  */
 const petik = '```'
 const nmr = '+'
const helpmenu = (wit,wita,wib,tampilTanggal, UserZeeone, tampilHari , limitawal, role, premi, sender, botname,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model ) => {
	return`╭─❒ *INFO BOT* 
│❒ ${petik}𝖭𝖺𝗆𝖺 : ${botname}${petik}
│❒ ${petik}Author : Nayla${petik}
│❒ ${petik}Recode : Zeeone${petik}
│❒ ${petik}Server : Baileys${petik}
│❒ ${petik}RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB${petik}
│❒ ${petik}MCC : ${mcc}${petik}
│❒ ${petik}MNC : ${mnc}${petik}
│❒ ${petik}Versi Os : ${os_version}${petik}
│❒ ${petik}Versi Hp : ${device_model}${petik}
│❒ ${petik}Merk Hp : ${device_manufacturer}${petik}
│❒ ${petik}WhatsApp : ${wa_version}${petik}
╰❒ ${petik}Total User : ${UserZeeone.length}${petik}

╭─❒ *INFO USER* 
│❒ ${petik}𝖭𝖺𝗆𝖺 : ${pushname}${petik}
│❒ ${petik}Nomor :${petik} ${nmr}${sender.split("@")[0]}
│❒ ${petik}Status : ${premi}${petik}
│❒ ${petik}Role : ${role}${petik}
╰❒ ${petik}Limit : ${limitawal} / Day${petik}

╭─❒ *INDONESIAN TIME* 
│❒ ${petik}Wib : ${wib}${petik}
│❒ ${petik}Wita : ${wita}${petik}
╰❒ ${petik}Wit : ${wit}${petik}

╭─❒ *TANGGAL*
│❒ ${petik}Hari : ${tampilTanggal}${petik}
╰❒ ${petik}${tampilHari}${petik}


╭──❒ *LIST MENU* 
│
├◪ ⧉ *GRUP MENU* ⧉
│  
│❒ ${petik}${prefix}hidetag${petik} 
│❒ ${petik}${prefix}add${petik} @user
│❒ ${petik}${prefix}kick${petik} @user
│❒ ${petik}${prefix}promote${petik} @user
│❒ ${petik}${prefix}demote${petik} @user
│❒ ${petik}${prefix}hidetag10${petik} 
│❒ ${petik}${prefix}group${petik} [ buka / tutup ]  
│❒ ${petik}${prefix}antigay${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}antibocil${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}antiwibu${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}antikasar${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}antitag${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}simih${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}level${petik} 
│❒ ${petik}${prefix}limit${petik} 
│❒ ${petik}${prefix}leveling${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}antijawa${petik}  [ 0 / 1 ] 
│❒ ${petik}${prefix}katajago${petik} 
│❒ ${petik}${prefix}linkgc${petik} 
│❒ ${petik}${prefix}tagall${petik} 
│❒ ${petik}${prefix}delete${petik}
│
├◪ ⧉ *IMAGE EFFECT* ⧉
│
${petik}│❒ ${prefix}trigger
│❒ ${prefix}gay
│❒ ${prefix}glass
│❒ ${prefix}passed
│❒ ${prefix}jail
│❒ ${prefix}comrade
│❒ ${prefix}hijau
│❒ ${prefix}biru
│❒ ${prefix}greyscale
│❒ ${prefix}invert
│❒ ${prefix}invert_greyscale
│❒ ${prefix}red
│❒ ${prefix}blurple
│❒ ${prefix}blurple2
│❒ ${prefix}wasted
│❒ ${prefix}pelangi
│❒ ${prefix}sepia
│❒ ${prefix}wanted
│❒ ${prefix}utatoo
│❒ ${prefix}unsharpen
│❒ ${prefix}thanos
│❒ ${prefix}sniper
│❒ ${prefix}sharpen
│❒ ${prefix}scary
│❒ ${prefix}rip
│❒ ${prefix}rejected
│❒ ${prefix}redple
│❒ ${prefix}posterize
│❒ ${prefix}ps4
│❒ ${prefix}pixelize
│❒ ${prefix}missionpassed
│❒ ${prefix}moustache
│❒ ${prefix}lookwhatkarenhave
│❒ ${prefix}instagram
│❒ ${prefix}glitch
│❒ ${prefix}frame
│❒ ${prefix}fire
│❒ ${prefix}distort
│❒ ${prefix}dictator
│❒ ${prefix}deepfry
│❒ ${prefix}ddungeon
│❒ ${prefix}circle
│❒ ${prefix}challenger
│❒ ${prefix}burn
│❒ ${prefix}brazzers
│❒ ${prefix}beautiful
│❒ ${prefix}beautiful${petik}  
│
├◪ ⧉ *STICK MENU* ⧉
│
│❒ ${petik}${prefix}awoawo${petik}  
│❒ ${petik}${prefix}benedict${petik}  
│❒ ${petik}${prefix}chat${petik}  
│❒ ${petik}${prefix}dbfly${petik}  
│❒ ${petik}${prefix}dino_kuning${petik}  
│❒ ${petik}${prefix}doge${petik}  
│❒ ${petik}${prefix}gojosatoru${petik}  
│❒ ${petik}${prefix}hope_boy${petik}  
│❒ ${petik}${prefix}jisoo${petik}  
│❒ ${petik}${prefix}kr_robot${petik}  
│❒ ${petik}${prefix}kucing${petik}  
│❒ ${petik}${prefix}lonte${petik}  
│❒ ${petik}${prefix}manusia_lidi${petik}  
│❒ ${petik}${prefix}menjamet${petik}  
│❒ ${petik}${prefix}meow${petik}  
│❒ ${petik}${prefix}nicholas${petik}  
│❒ ${petik}${prefix}patrick${petik}  
│❒ ${petik}${prefix}popoci${petik} 
│❒ ${petik}${prefix}sponsbob${petik}  
│❒ ${petik}${prefix}kawan_sponsbob${petik}  
│❒ ${petik}${prefix}tyni${petik} 
│
├◪ ⧉ *ANIME MENU* ⧉
│
│❒ ${petik}${prefix}anna${petik}
│❒ ${petik}${prefix}asuna_yuki${petik} 
│❒ ${petik}${prefix}ayuzawa${petik} 
│❒ ${petik}${prefix}chitoge${petik} 
│❒ ${petik}${prefix}emilia${petik}
│❒ ${petik}${prefix}erza${petik} 
│❒ ${petik}${prefix}hinata${petik} 
│❒ ${petik}${prefix}inori${petik} 
│❒ ${petik}${prefix}kaga_kouko${petik} 
│❒ ${petik}${prefix}kaori_miyazono${petik} 
│❒ ${petik}${prefix}kotori_minami${petik}
│❒ ${petik}${prefix}mikasa${petik} 
│❒ ${petik}${prefix}mio_akiyama${petik} 
│❒ ${petik}${prefix}mizore_sirayuki${petik} 
│❒ ${petik}${prefix}nakiri_alice${petik} 
│❒ ${petik}${prefix}naruto${petik} 
│❒ ${petik}${prefix}riyas_gremori${petik}
│❒ ${petik}${prefix}sakura${petik} 
│❒ ${petik}${prefix}sasuke${petik} 
│❒ ${petik}${prefix}sento_isuzu${petik} 
│❒ ${petik}${prefix}shana${petik} 
│❒ ${petik}${prefix}shiina${petik} 
│❒ ${petik}${prefix}shinka${petik}
│❒ ${petik}${prefix}winry${petik}
│❒ ${petik}${prefix}yukino${petik} 
│❒ ${petik}${prefix}yuzuki${petik} 
│❒ ${petik}${prefix}akame${petik}
│❒ ${petik}${prefix}mikosiba${petik}
│❒ ${petik}${prefix}luffy
│❒ ${prefix}zoro
│❒ ${prefix}sanji
│❒ ${prefix}ussop
│❒ ${prefix}minato
│❒ ${prefix}boruto
│❒ ${prefix}sarada
│❒ ${prefix}mitsuki
│❒ ${prefix}orochimaru
│❒ ${prefix}tsunade
│❒ ${prefix}kakashi
│❒ ${prefix}killua
│❒ ${prefix}rimuru
│❒ ${prefix}sagiri
│❒ ${prefix}natsu
│❒ ${prefix}tanjirou
│❒ ${prefix}loli${petik}
│
├◪ ⧉ *PRO MENU* ⧉
│
│❒ ${petik}${prefix}nulis1${petik} 
│❒ ${petik}${prefix}nulis2${petik} 
│❒ ${petik}${prefix}nulis3${petik} 
│❒ ${petik}${prefix}nulis4${petik} 
│❒ ${petik}${prefix}nulis5${petik} 
│❒ ${petik}${prefix}nulis6${petik} 
│❒ ${petik}${prefix}video1${petik} 
│❒ ${petik}${prefix}video2${petik} 
│❒ ${petik}${prefix}video3${petik} 
│❒ ${petik}${prefix}video4${petik} 
│❒ ${petik}${prefix}video5${petik} 
│❒ ${petik}${prefix}video6${petik}
│
├◪ ⧉ *QUOTES MENU* ⧉
│
│❒ ${petik}${prefix}katailham${petik}  
│❒ ${petik}${prefix}dare${petik}   
│❒ ${petik}${prefix}truth${petik}  
│❒ ${petik}${prefix}katabijak_lucu${petik}   
│❒ ${petik}${prefix}katacaklontong${petik}  
│❒ ${petik}${prefix}katadilan${petik}  
│
├◪ ⧉ *DOWNLOAD MENU* ⧉
│
│❒ ${petik}${prefix}telesticker${petik}  
│❒ ${petik}${prefix}tiktokmusic${petik}  
│❒ ${petik}${prefix}tiktok${petik}  
│❒ ${petik}${prefix}tiktoknowm${petik}  
│❒ ${petik}${prefix}pinterestdl${petik}  
│❒ ${petik}${prefix}pinterest${petik}  
│❒ ${petik}${prefix}pinterest2${petik}  
│❒ ${petik}${prefix}igfoto${petik}  
│❒ ${petik}${prefix}igvideo${petik}  
│❒ ${petik}${prefix}pixiv${petik}  
│❒ ${petik}${prefix}pixivdl${petik}  
│❒ ${petik}${prefix}xhamstersearch${petik}  
│❒ ${petik}${prefix}ytsearch${petik}  
│❒ ${petik}${prefix}ytmp3${petik}  
│❒ ${petik}${prefix}xhamster${petik}  
│❒ ${petik}${prefix}xnxxsearch${petik}  
│❒ ${petik}${prefix}xnxx${petik}  
│❒ ${petik}${prefix}nhentai${petik}  
│❒ ${petik}${prefix}nhentaipdf${petik}  
│❒ ${petik}${prefix}nhentaisearch${petik} 
│❒ ${petik}${prefix}nekopoi${petik}   
│❒ ${petik}${prefix}nekopoisearch${petik}   
│❒ ${petik}${prefix}ytmp4${petik}  
│❒ ${petik}${prefix}play${petik}  
│❒ ${petik}${prefix}playmp3${petik}  
│❒ ${petik}${prefix}playmp4${petik}  
│❒ ${petik}${prefix}play2${petik}  
│❒ ${petik}${prefix}kontenyt${petik} 
│
├◪ ⧉ *GACHA CECAN* ⧉
│
│❒ ${petik}${prefix}china${petik}  
│❒ ${petik}${prefix}indonesia${petik}  
│❒ ${petik}${prefix}malaysia${petik}  
│❒ ${petik}${prefix}thailand${petik}  
│❒ ${petik}${prefix}korea${petik} 
│❒ ${petik}${prefix}japan${petik} 
│❒ ${petik}${prefix}vietnam${petik}  
│❒ ${petik}${prefix}jenni${petik}  
│❒ ${petik}${prefix}jiso${petik}  
│❒ ${petik}${prefix}lisa${petik} 
│❒ ${petik}${prefix}rose${petik} 
│
├◪ ⧉ *GACHA COGAN* ⧉
│
│❒ ${petik}${prefix}baekhyung${petik}  
│❒ ${petik}${prefix}dohkyungsoo${petik}  
│❒ ${petik}${prefix}huangzitao${petik}  
│❒ ${petik}${prefix}jhope${petik}  
│❒ ${petik}${prefix}jimin${petik} 
│❒ ${petik}${prefix}jungkook${petik} 
│❒ ${petik}${prefix}kimjondae${petik}  
│❒ ${petik}${prefix}kimjong${petik}  
│❒ ${petik}${prefix}kimjunmyeon${petik}  
│❒ ${petik}${prefix}kimminseok${petik} 
│❒ ${petik}${prefix}kimnanjoon${petik}  
│❒ ${petik}${prefix}kimseok${petik}  
│❒ ${petik}${prefix}kimtaehyung${petik}  
│❒ ${petik}${prefix}luhan${petik}  
│❒ ${petik}${prefix}ohsehun${petik} 
│❒ ${petik}${prefix}parkchanyeol${petik} 
│❒ ${petik}${prefix}suga${petik}  
│❒ ${petik}${prefix}kimtaehyung${petik} 
│ 
├◪ ⧉ *NSFW & SFW MENU* ⧉
│
│❒ ${petik}${prefix}ahegao${petik} 
│❒ ${petik}${prefix}ass${petik} 
│❒ ${petik}${prefix}bdsm${petik} 
│❒ ${petik}${prefix}blowjob${petik} 
│❒ ${petik}${prefix}cuckold${petik}
│❒ ${petik}${prefix}cum${petik} 
│❒ ${petik}${prefix}ero${petik} 
│❒ ${petik}${prefix}femdom${petik} 
│❒ ${petik}${prefix}foot${petik} 
│❒ ${petik}${prefix}gangbang${petik} 
│❒ ${petik}${prefix}glasses${petik}
│❒ ${petik}${prefix}hentai${petik} 
│❒ ${petik}${prefix}hentai_gifs${petik} 
│❒ ${petik}${prefix}jahy${petik} 
│❒ ${petik}${prefix}manga${petik} 
│❒ ${petik}${prefix}masturbation${petik} 
│❒ ${petik}${prefix}neko${petik}
│❒ ${petik}${prefix}orgy${petik} 
│❒ ${petik}${prefix}panties${petik} 
│❒ ${petik}${prefix}pussy${petik} 
│❒ ${petik}${prefix}neko_sfw${petik} 
│❒ ${petik}${prefix}tentacles${petik} 
│❒ ${petik}${prefix}thighs${petik}
│❒ ${petik}${prefix}yuri${petik}
│❒ ${petik}${prefix}zettai${petik}
│
├◪ ⧉ *ASUPAN MENU* ⧉
│
${petik}│❒ ${prefix}rikagusriani 
│❒ ${prefix}ukhty 
│❒ ${prefix}santuy 
│❒ ${prefix}geayubi   
│❒ ${prefix}bocil
│❒ ${prefix}asupan
│❒ ${prefix}chika 
│❒ ${prefix}delvira 
│❒ ${prefix}ayu   
│❒ ${prefix}bunga
│❒ ${prefix}aura
│❒ ${prefix}nisa 
│❒ ${prefix}ziva 
│❒ ${prefix}yana   
│❒ ${prefix}viona
│❒ ${prefix}syania
│❒ ${prefix}riri   
│❒ ${prefix}syifa
│❒ ${prefix}mama_gina
│❒ ${prefix}alcakenya 
│❒ ${prefix}mangayutri${petik}  
│
├◪ ⧉ *SOUND MENU* ⧉
│
│❒ ${petik}${prefix}tomp3${petik} 
│❒ ${petik}${prefix}sound1${petik}  
│❒ ${petik}${prefix}sound2${petik}  
│❒ ${petik}${prefix}sound3${petik}  
│❒ ${petik}${prefix}sound4${petik}  
│❒ ${petik}${prefix}sound5${petik}  
│❒ ${petik}${prefix}sound6${petik}  
│❒ ${petik}${prefix}sound7${petik}  
│❒ ${petik}${prefix}sound8${petik}  
│❒ ${petik}${prefix}sound9${petik}  
│❒ ${petik}${prefix}sound10${petik}  
│❒ ${petik}${prefix}sound11${petik}  
│❒ ${petik}${prefix}sound12${petik}  
│❒ ${petik}${prefix}sound13${petik}  
│❒ ${petik}${prefix}sound14${petik}  
│❒ ${petik}${prefix}sound15${petik}  
│❒ ${petik}${prefix}sound16${petik}  
│❒ ${petik}${prefix}sound17${petik}  
│❒ ${petik}${prefix}sound18${petik}  
│❒ ${petik}${prefix}sound19${petik}  
│❒ ${petik}${prefix}sound20${petik}  
│❒ ${petik}${prefix}sound21${petik}  
│❒ ${petik}${prefix}sound22${petik}  
│❒ ${petik}${prefix}sound23${petik}  
│❒ ${petik}${prefix}sound24${petik}  
│❒ ${petik}${prefix}sound25${petik} 
│
├◪ ⧉ *PORN MENU* ⧉
│
│❒ ${petik}${prefix}indo1${petik}   
│❒ ${petik}${prefix}indo2${petik}   
│❒ ${petik}${prefix}indo3${petik}   
│❒ ${petik}${prefix}indo4${petik}   
│❒ ${petik}${prefix}indo5${petik}   
│❒ ${petik}${prefix}indo6${petik}   
│❒ ${petik}${prefix}indo7${petik}   
│❒ ${petik}${prefix}indo8${petik}   
│❒ ${petik}${prefix}indo9${petik}   
│❒ ${petik}${prefix}indo10${petik}   
│❒ ${petik}${prefix}indo11${petik}   
│❒ ${petik}${prefix}indo12${petik}   
│❒ ${petik}${prefix}indo13${petik}   
│❒ ${petik}${prefix}indo14${petik}   
│❒ ${petik}${prefix}indo15${petik}   
│❒ ${petik}${prefix}indo16${petik}   
│❒ ${petik}${prefix}indo17${petik}   
│❒ ${petik}${prefix}indo18${petik}   
│❒ ${petik}${prefix}indo19${petik}   
│❒ ${petik}${prefix}indo20${petik}   
│❒ ${petik}${prefix}indo21${petik}   
│❒ ${petik}${prefix}indo22${petik}   
│❒ ${petik}${prefix}indo23${petik}   
│❒ ${petik}${prefix}indo24${petik}   
│❒ ${petik}${prefix}indo25${petik} 
│
├◪ ⧉ *STORAGE MENU* ⧉
│ 
│❒ ${petik}${prefix}chatlist${petik}  
│❒ ${petik}${prefix}addsticker${petik}  
│❒ ${petik}${prefix}addvn${petik}  
│❒ ${petik}${prefix}getvn${petik}  
│❒ ${petik}${prefix}getsticker${petik}  
│❒ ${petik}${prefix}liststicker${petik}  
│❒ ${petik}${prefix}listvn${petik}  
│❒ ${petik}${prefix}addimage${petik}  
│❒ ${petik}${prefix}getimage${petik}  
│❒ ${petik}${prefix}imagelist${petik}  
│❒ ${petik}${prefix}addvideo${petik}  
│❒ ${petik}${prefix}getvideo${petik}  
│❒ ${petik}${prefix}listvideo${petik} 
│❒ ${petik}${prefix}addcmd${petik} 
│❒ ${petik}${prefix}listcmd${petik} 
│❒ ${petik}${prefix}delcmd${petik} 
│
├◪ ⧉ *ISLAMIC MENU* ⧉
│ 
│❒ ${petik}${prefix}kisah_nabi${petik}  
│❒ ${petik}${prefix}ayatkursi${petik}  
│❒ ${petik}${prefix}tahlil${petik}  
│❒ ${petik}${prefix}wirid${petik}  
│❒ ${petik}${prefix}quran${petik}  
│❒ ${petik}${prefix}alquran${petik}  
│❒ ${petik}${prefix}alquranaudio${petik}  
│❒ ${petik}${prefix}hadits${petik}  
│❒ ${petik}${prefix}hadits2${petik}  
│❒ ${petik}${prefix}listsurah${petik}  
│❒ ${petik}${prefix}doa_harian${petik}  
│❒ ${petik}${prefix}niat_shalat${petik}  
│❒ ${petik}${prefix}bacaan_shalat${petik}  
│
├◪ ⧉ *CHECK MENU* ⧉
│
│❒ ${petik}${prefix}gantengcek${petik}  
│❒ ${petik}${prefix}cantikcek${petik}  
│❒ ${petik}${prefix}jelekcek${petik}  
│❒ ${petik}${prefix}goblokcek${petik}  
│❒ ${petik}${prefix}begocek${petik}  
│❒ ${petik}${prefix}pintercek${petik}  
│❒ ${petik}${prefix}jagocek${petik}  
│❒ ${petik}${prefix}nolepcek${petik}  
│❒ ${petik}${prefix}babicek${petik}  
│❒ ${petik}${prefix}bebancek${petik}  
│❒ ${petik}${prefix}baikcek${petik}  
│❒ ${petik}${prefix}jahatcek${petik}  
│❒ ${petik}${prefix}anjingcek${petik}  
│❒ ${petik}${prefix}haramcek${petik}  
│❒ ${petik}${prefix}kontolcek${petik}  
│❒ ${petik}${prefix}pakboycek${petik}  
│❒ ${petik}${prefix}pakgirlcek${petik}  
│❒ ${petik}${prefix}sangecek${petik}  
│❒ ${petik}${prefix}bapercek${petik} 
│
├◪ ⧉ *TAG MENU* ⧉
│
│❒ ${petik}${prefix}ganteng${petik}  
│❒ ${petik}${prefix}cantik${petik}  
│❒ ${petik}${prefix}jelek${petik}  
│❒ ${petik}${prefix}goblok${petik}  
│❒ ${petik}${prefix}bego${petik}  
│❒ ${petik}${prefix}pinter${petik}  
│❒ ${petik}${prefix}jago${petik}  
│❒ ${petik}${prefix}babi${petik}  
│❒ ${petik}${prefix}beban${petik}  
│❒ ${petik}${prefix}baik${petik}  
│❒ ${petik}${prefix}jahat${petik}  
│❒ ${petik}${prefix}anjing${petik}  
│❒ ${petik}${prefix}monyet${petik}  
│❒ ${petik}${prefix}haram${petik}  
│❒ ${petik}${prefix}kontol${petik}  
│❒ ${petik}${prefix}pakboy${petik}  
│❒ ${petik}${prefix}pakgirl${petik}  
│❒ ${petik}${prefix}sadboy${petik}  
│❒ ${petik}${prefix}sadgirl${petik}  
│❒ ${petik}${prefix}wibu${petik}  
│❒ ${petik}${prefix}nolep${petik}  
│❒ ${petik}${prefix}hebat${petik} 
│
├◪ ⧉ *GAME MENU* ⧉
│
│❒ ${petik}${prefix}slot${petik}  
│❒ ${petik}${prefix}simi${petik}  
│❒ ${petik}${prefix}jumlah${petik}   
│❒ ${petik}${prefix}tebakgambar${petik}   
│❒ ${petik}${prefix}kapankah${petik}  
│❒ ${petik}${prefix}apakah${petik}  
│❒ ${petik}${prefix}ramalnomer${petik}   
│❒ ${petik}${prefix}ramalcinta${petik}   
│❒ ${petik}${prefix}jodohbali${petik}   
│❒ ${petik}${prefix}ramalnikah${petik}   
│❒ ${petik}${prefix}taksirmimpi${petik}   
│❒ ${petik}${prefix}suit${petik}      
│❒ ${petik}${prefix}boomtext${petik}  
│❒ ${petik}${prefix}holoh${petik}  
│❒ ${petik}${prefix}heleh${petik}  
│❒ ${petik}${prefix}huluh${petik}  
│❒ ${petik}${prefix}hilih${petik}  
│❒ ${petik}${prefix}halah${petik}   
│❒ ${petik}${prefix}kapital${petik}  
│❒ ${petik}${prefix}textfont${petik}  
│❒ ${petik}${prefix}tebak${petik}  
│❒ ${petik}${prefix}oxo${petik}  
│❒ ${petik}${prefix}pesan${petik}  
│❒ ${petik}${prefix}tebakkimia${petik}  
│❒ ${petik}${prefix}tebaklirik${petik}  
│❒ ${petik}${prefix}tebakin1${petik}  
│❒ ${petik}${prefix}tebakin2${petik} 
│
├◪ ⧉ *RANDOM TEXT* ⧉
│
│❒ ${petik}${prefix}quotes2 ${petik} 
│❒ ${petik}${prefix}grubwa${petik}  
│❒ ${petik}${prefix}nickff${petik} 
│❒ ${petik}${prefix}brainly${petik}  
│❒ ${petik}${prefix}quotes1${petik}  
│❒ ${petik}${prefix}kusonime${petik}  
│❒ ${petik}${prefix}renungan${petik}  
│❒ ${petik}${prefix}samehadaku${petik}  
│❒ ${petik}${prefix}infonomer${petik}  
│❒ ${petik}${prefix}jadwaltv${petik}  
│❒ ${petik}${prefix}tvjadwal${petik}  
│❒ ${petik}${prefix}fml${petik}  
│❒ ${petik}${prefix}cinta${petik}  
│❒ ${petik}${prefix}resepmasakan${petik}  
│❒ ${petik}${prefix}cersex${petik}  
│❒ ${petik}${prefix}cerpen${petik}  
│❒ ${petik}${prefix}jadwalsholat${petik}  
│❒ ${petik}${prefix}pantun${petik}  
│❒ ${petik}${prefix}cuaca${petik}  
│❒ ${petik}${prefix}namaninja${petik}  
│❒ ${petik}${prefix}fake${petik}    
│❒ ${petik}${prefix}quotes${petik}  
│❒ ${petik}${prefix}quotesnime${petik}  
│❒ ${petik}${prefix}kbbilazimedia${petik}  
│❒ ${petik}${prefix}covid${petik}  
│❒ ${petik}${prefix}wikiid${petik}  
│❒ ${petik}${prefix}covidid${petik}  
│❒ ${petik}${prefix}kbbi${petik}  
│❒ ${petik}${prefix}infogempa${petik}  
│❒ ${petik}${prefix}randomquran${petik}  
│❒ ${petik}${prefix}kisanabi${petik}  
│❒ ${petik}${prefix}artinama${petik}  
│❒ ${petik}${prefix}artimimpi${petik}  
│❒ ${petik}${prefix}artijadian${petik}  
│❒ ${petik}${prefix}chord${petik}  
│❒ ${petik}${prefix}lirik${petik} 
│
├◪ ⧉ *FAST MENU* ⧉
│
│❒ ${petik}${prefix}fb${petik}  
│❒ ${petik}${prefix}tts${petik}   
│❒ ${petik}${prefix}stalktwit${petik}  
│❒ ${petik}${prefix}stalkgithub${petik}   
│❒ ${petik}${prefix}randomhusbu${petik}  
│❒ ${petik}${prefix}pinterest${petik}
│❒ ${petik}${prefix}pinterest2${petik}  
│❒ ${petik}${prefix}randomwaifu${petik}  
│❒ ${petik}${prefix}randomwaifu1${petik}  
│❒ ${petik}${prefix}stalkig${petik} 
│❒ ${petik}${prefix}estetikpic${petik} 
│❒ ${petik}${prefix}memeindo${petik}
│❒ ${petik}${prefix}darkjokes${petik}  
│❒ ${petik}${prefix}urlshort${petik}  
│❒ ${petik}${prefix}shortener${petik}  
│❒ ${petik}${prefix}fox${petik}  
│❒ ${petik}${prefix}dog${petik}  
│❒ ${petik}${prefix}cat${petik}  
│❒ ${petik}${prefix}panda${petik}  
│❒ ${petik}${prefix}panda1${petik}  
│❒ ${petik}${prefix}bird${petik}  
│❒ ${petik}${prefix}koala${petik}  
│❒ ${petik}${prefix}meme${petik}     
│❒ ${petik}${prefix}ngakak${petik}  
│❒ ${petik}${prefix}pin${petik}   
│❒ ${petik}${prefix}foto${petik}   
│❒ ${petik}${prefix}bts${petik}  
│❒ ${petik}${prefix}exo${petik}  
│❒ ${petik}${prefix}blackpink${petik}   
│❒ ${petik}${prefix}manga1${petik}  
│❒ ${petik}${prefix}character${petik}   
│❒ ${petik}${prefix}bug${petik} 
│❒ ${petik}${prefix}deteksiumur${petik} 
│
├◪ ⧉ *SERTIFIKAT MENU* ⧉
│
│❒ ${petik}${prefix}ffserti${petik}   
│❒ ${petik}${prefix}ffserti2${petik}  
│❒ ${petik}${prefix}ffserti3${petik}  
│❒ ${petik}${prefix}ffserti4${petik}  
│❒ ${petik}${prefix}ffserti5${petik}  
│❒ ${petik}${prefix}pubgserti${petik}  
│❒ ${petik}${prefix}pubgserti2${petik}  
│❒ ${petik}${prefix}pubgserti3${petik}  
│❒ ${petik}${prefix}pubgserti4${petik}  
│❒ ${petik}${prefix}pubgserti5${petik}  
│❒ ${petik}${prefix}mlserti${petik}  
│❒ ${petik}${prefix}mlserti2${petik}  
│❒ ${petik}${prefix}mlserti3${petik}  
│❒ ${petik}${prefix}mlserti4${petik}  
│❒ ${petik}${prefix}mlserti5${petik} 
│
├◪ ⧉ *OWNER MENU* ⧉
│
│❒ ${petik}${prefix}dellprem${petik}   
│❒ ${petik}${prefix}addprem${petik}  
│❒ ${petik}${prefix}clearall${petik}  
│❒ ${petik}${prefix}bc${petik}  
│❒ ${petik}${prefix}bcsticker${petik}  
│❒ ${petik}${prefix}bcvideo${petik} 
│❒ ${petik}${prefix}bcaudio${petik}  
│❒ ${petik}${prefix}bcgif${petik}  
│❒ ${petik}${prefix}owner${petik}  
│❒ ${petik}${prefix}author${petik}   
│❒ ${petik}${prefix}setthum${petik}  
│❒ ${petik}${prefix}setpp${petik}  
│❒ ${petik}${prefix}setprefix${petik}  
│❒ ${petik}${prefix}setreply${petik} 
│
├◪ ⧉ *MAKER MENU* ⧉
│
│❒ ${petik}${prefix}emoji${petik}  
│❒ ${petik}${prefix}neon1${petik}  
│❒ ${petik}${prefix}text3d${petik}  
│❒ ${petik}${prefix}galaxy${petik}  
│❒ ${petik}${prefix}gaming${petik}  
│❒ ${petik}${prefix}colors${petik}  
│❒ ${petik}${prefix}kling${petik}  
│❒ ${petik}${prefix}ttp4${petik}  
│❒ ${petik}${prefix}ttp3${petik}  
│❒ ${petik}${prefix}ttp2${petik}  
│❒ ${petik}${prefix}ttp1${petik}  
│❒ ${petik}${prefix}attp${petik} 
│❒ ${petik}${prefix}sticker${petik}  
│❒ ${petik}${prefix}stickergif${petik} 
│❒ ${petik}${prefix}removebg${petik}   
│❒ ${petik}${prefix}tahta${petik} 
│❒ ${petik}${prefix}wall${petik} 
│❒ ${petik}${prefix}neon2${petik} 
│❒ ${petik}${prefix}wolf${petik} 
│❒ ${petik}${prefix}tfire${petik} 
│❒ ${petik}${prefix}ytgold${petik} 
│❒ ${petik}${prefix}ytsilver${petik} 
│❒ ${petik}${prefix}t3d${petik} 
│❒ ${petik}${prefix}logoa${petik} 
│❒ ${petik}${prefix}pornhub${petik} 
│❒ ${petik}${prefix}marvel${petik} 
│❒ ${petik}${prefix}leavest${petik} 
│❒ ${petik}${prefix}phcoment${petik} 
│❒ ${petik}${prefix}greenneon${petik}
│❒ ${petik}${prefix}advanceglow${petik}
│❒ ${petik}${prefix}futureneon${petik}
│❒ ${petik}${prefix}sandwriting${petik}
│❒ ${petik}${prefix}sandsummer${petik}
│❒ ${petik}${prefix}sandengraved${petik}
│❒ ${petik}${prefix}metaldark${petik}
│❒ ${petik}${prefix}neonlight${petik}
│❒ ${petik}${prefix}holographic${petik}
│❒ ${petik}${prefix}text1917${petik}
│❒ ${petik}${prefix}minion${petik}
│❒ ${petik}${prefix}deluxesilver${petik}
│❒ ${petik}${prefix}newyearcard${petik}
│❒ ${petik}${prefix}bloodfrosted${petik}
│❒ ${petik}${prefix}halloween${petik}
│❒ ${petik}${prefix}jokerlogo${petik}
│❒ ${petik}${prefix}fireworksparkle${petik}
│❒ ${petik}${prefix}natureleaves${petik}
│❒ ${petik}${prefix}bokeh${petik}
│❒ ${petik}${prefix}toxic${petik}
│❒ ${petik}${prefix}strawberry${petik}
│❒ ${petik}${prefix}box3d${petik}
│❒ ${petik}${prefix}roadwarning${petik}
│❒ ${petik}${prefix}breakwall${petik}
│❒ ${petik}${prefix}icecold${petik}
│❒ ${petik}${prefix}luxury${petik}
│❒ ${petik}${prefix}cloud${petik}
│❒ ${petik}${prefix}summersand${petik}
│❒ ${petik}${prefix}horrorblood${petik}
│❒ ${petik}${prefix}thunder${petik}
${petik}│❒ ${prefix}wetglass
│❒ ${prefix}multicolor3d
│❒ ${prefix}watercolor
│❒ ${prefix}luxurygold
│❒ ${prefix}galaxywallpaper
│❒ ${prefix}lighttext
│❒ ${prefix}beautifulflower
│❒ ${prefix}puppycute
│❒ ${prefix}royaltext
│❒ ${prefix}heartshaped
│❒ ${prefix}birthdaycake
│❒ ${prefix}galaxystyle
│❒ ${prefix}hologram3d
│❒ ${prefix}glossychrome
│❒ ${prefix}greenbush
│❒ ${prefix}metallogo
│❒ ${prefix}noeltext
│❒ ${prefix}glittergold
│❒ ${prefix}textcake
│❒ ${prefix}starsnight
│❒ ${prefix}wooden3d
│❒ ${prefix}textbyname
│❒ ${prefix}writegalacy
│❒ ${prefix}galaxybat
│❒ ${prefix}snow3d
│❒ ${prefix}birthdayday
│❒ ${prefix}goldplaybutton
│❒ ${prefix}silverplaybutton
│❒ ${prefix}freefire${petik}
│
├◪ ⧉ *SPESIAL MENU* ⧉
│
│❒ ${petik}${prefix}sewabot${petik} 
│❒ ${petik}${prefix}deteksiwajah${petik} 
│❒ ${petik}${prefix}readmore${petik} 
│❒ ${petik}${prefix}randomwibu${petik} 
│❒ ${petik}${prefix}phkomen${petik}  
│❒ ${petik}${prefix}semoji${petik}  
│❒ ${petik}${prefix}jadian${petik}  
│❒ ${petik}${prefix}citacita${petik}  
│❒ ${petik}${prefix}laut${petik}  
│❒ ${petik}${prefix}darat${petik}  
│❒ ${petik}${prefix}udara${petik}  
│❒ ${petik}${prefix}fakta${petik}  
│❒ ${petik}${prefix}gcard${petik}  
│❒ ${petik}${prefix}ssweb${petik}  
│❒ ${petik}${prefix}katailham${petik}  
╰❒ ${petik}${prefix}randomwibu${petik} 
`
}
/*

╭─⧉ *THANKS TO* ⧉
├◪ 
│❒ ${petik}NAYLACHAN${petik}  
│❒ ${petik}RYNZ${petik}  
│❒ ${petik}LOLI KILLERS${petik}  
│❒ ${petik}ARA-ARA${petik} 
│❒ ${petik}ZEEONE${petik} 
╰───────────────┈ ⳹
*/
const grupmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *GRUP MENU*  
├◪
│❒ ${petik}${prefix}hidetag${petik}  
│❒ ${petik}${prefix}add${petik}
│❒ ${petik}${prefix}addreply${petik}  
│❒ ${petik}${prefix}kick${petik}  
│❒ ${petik}${prefix}kickreply${petik}  
│❒ ${petik}${prefix}promote${petik}  
│❒ ${petik}${prefix}demote${petik}  
│❒ ${petik}${prefix}antilink${petik}    
│❒ ${petik}${prefix}hidetag10${petik} 
│❒ ${petik}${prefix}group${petik}
│❒ ${petik}${prefix}setdeskgc${petik}  
│❒ ${petik}${prefix}setnamegc${petik}
│❒ ${petik}${prefix}hacked${petik}
│❒ ${petik}${prefix}speed${petik}
│❒ ${petik}${prefix}creategroup${petik}  
│❒ ${petik}${prefix}antigay${petik}  
│❒ ${petik}${prefix}antibocil${petik}  
│❒ ${petik}${prefix}antiwibu${petik}  
│❒ ${petik}${prefix}antikasar${petik}  
│❒ ${petik}${prefix}antitag${petik}  
│❒ ${petik}${prefix}simih${petik} [ 0 / 1 ] 
│❒ ${petik}${prefix}level${petik}  
│❒ ${petik}${prefix}limit${petik}  
│❒ ${petik}${prefix}leveling${petik}  
│❒ ${petik}${prefix}antijawa${petik}   
│❒ ${petik}${prefix}katajago${petik}  
│❒ ${petik}${prefix}linkgc${petik}  
│❒ ${petik}${prefix}tagall${petik}  
╰❒ ${petik}${prefix}delete${petik} 
`
}
const stickmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *STICK MENU*  
├◪
│❒ ${petik}${prefix}awoawo${petik}  
│❒ ${petik}${prefix}benedict${petik}  
│❒ ${petik}${prefix}chat${petik}  
│❒ ${petik}${prefix}dbfly${petik}  
│❒ ${petik}${prefix}dino_kuning${petik}  
│❒ ${petik}${prefix}doge${petik}  
│❒ ${petik}${prefix}gojosatoru${petik}  
│❒ ${petik}${prefix}hope_boy${petik}  
│❒ ${petik}${prefix}jisoo${petik}  
│❒ ${petik}${prefix}kr_robot${petik}  
│❒ ${petik}${prefix}kucing${petik}  
│❒ ${petik}${prefix}lonte${petik}  
│❒ ${petik}${prefix}manusia_lidi${petik}  
│❒ ${petik}${prefix}menjamet${petik}  
│❒ ${petik}${prefix}meow${petik}  
│❒ ${petik}${prefix}nicholas${petik}  
│❒ ${petik}${prefix}patrick${petik}  
│❒ ${petik}${prefix}popoci${petik} 
│❒ ${petik}${prefix}sponsbob${petik}  
│❒ ${petik}${prefix}kawan_sponsbob${petik}  
╰❒ ${petik}${prefix}tyni${petik} 
`
}

const promenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *PRO MENU*
├◪
│❒ ${petik}${prefix}nulis1${petik}  
│❒ ${petik}${prefix}nulis2${petik}  
│❒ ${petik}${prefix}nulis3${petik}  
│❒ ${petik}${prefix}nulis4${petik}  
│❒ ${petik}${prefix}nulis5${petik}  
│❒ ${petik}${prefix}nulis6${petik}  
│❒ ${petik}${prefix}video1${petik}  
│❒ ${petik}${prefix}video2${petik}  
│❒ ${petik}${prefix}video3${petik}  
│❒ ${petik}${prefix}video4${petik}  
│❒ ${petik}${prefix}video5${petik}  
╰❒ ${petik}${prefix}video6${petik} 
`
}

const downloadmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *DOWNLOAD MENU*
├◪
│❒ ${petik}${prefix}telesticker${petik}  
│❒ ${petik}${prefix}tiktokmusic${petik}  
│❒ ${petik}${prefix}tiktoknowm${petik}
│❒ ${petik}${prefix}tiktok${petik}  
│❒ ${petik}${prefix}pinterestdl${petik}  
│❒ ${petik}${prefix}pinterest${petik}  
│❒ ${petik}${prefix}pinterest2${petik}  
│❒ ${petik}${prefix}igfoto${petik}  
│❒ ${petik}${prefix}igvideo${petik}  
│❒ ${petik}${prefix}pixiv${petik}  
│❒ ${petik}${prefix}pixivdl${petik}  
│❒ ${petik}${prefix}xhamstersearch${petik}  
│❒ ${petik}${prefix}ytsearch${petik}  
│❒ ${petik}${prefix}ytmp3${petik}  
│❒ ${petik}${prefix}xhamster${petik}  
│❒ ${petik}${prefix}xnxxsearch${petik}  
│❒ ${petik}${prefix}xnxx${petik}  
│❒ ${petik}${prefix}nhentai${petik}  
│❒ ${petik}${prefix}nhentaipdf${petik}  
│❒ ${petik}${prefix}nhentaisearch${petik} 
│❒ ${petik}${prefix}nekopoi${petik}   
│❒ ${petik}${prefix}nekopoisearch${petik}   
│❒ ${petik}${prefix}ytmp4${petik}  
│❒ ${petik}${prefix}playmp3${petik}  
│❒ ${petik}${prefix}playmp4${petik}  
│❒ ${petik}${prefix}play${petik}  
│❒ ${petik}${prefix}ytsearch${petik}  
╰❒ ${petik}${prefix}kontenyt${petik} 
`
}

const soundmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *SOUND MENU*
├◪
│❒ ${petik}${prefix}tomp3${petik}  
│❒ ${petik}${prefix}sound1${petik}  
│❒ ${petik}${prefix}sound2${petik}  
│❒ ${petik}${prefix}sound3${petik}  
│❒ ${petik}${prefix}sound4${petik}  
│❒ ${petik}${prefix}sound5${petik}  
│❒ ${petik}${prefix}sound6${petik}  
│❒ ${petik}${prefix}sound7${petik}  
│❒ ${petik}${prefix}sound8${petik}  
│❒ ${petik}${prefix}sound9${petik}  
│❒ ${petik}${prefix}sound10${petik}  
│❒ ${petik}${prefix}sound11${petik}  
│❒ ${petik}${prefix}sound12${petik}  
│❒ ${petik}${prefix}sound13${petik}  
│❒ ${petik}${prefix}sound14${petik}  
│❒ ${petik}${prefix}sound15${petik}  
│❒ ${petik}${prefix}sound16${petik}  
│❒ ${petik}${prefix}sound17${petik}  
│❒ ${petik}${prefix}sound18${petik}  
│❒ ${petik}${prefix}sound19${petik}  
│❒ ${petik}${prefix}sound20${petik}  
│❒ ${petik}${prefix}sound21${petik}  
│❒ ${petik}${prefix}sound22${petik}  
│❒ ${petik}${prefix}sound23${petik}  
│❒ ${petik}${prefix}sound24${petik}  
╰❒ ${petik}${prefix}sound25${petik} 
`
}

const pornmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *PORN MENU*
├◪
│❒ ${petik}${prefix}indo1${petik}   
│❒ ${petik}${prefix}indo2${petik}   
│❒ ${petik}${prefix}indo3${petik}   
│❒ ${petik}${prefix}indo4${petik}   
│❒ ${petik}${prefix}indo5${petik}   
│❒ ${petik}${prefix}indo6${petik}   
│❒ ${petik}${prefix}indo7${petik}   
│❒ ${petik}${prefix}indo8${petik}   
│❒ ${petik}${prefix}indo9${petik}   
│❒ ${petik}${prefix}indo10${petik}   
│❒ ${petik}${prefix}indo11${petik}   
│❒ ${petik}${prefix}indo12${petik}   
│❒ ${petik}${prefix}indo13${petik}   
│❒ ${petik}${prefix}indo14${petik}   
│❒ ${petik}${prefix}indo15${petik}   
│❒ ${petik}${prefix}indo16${petik}   
│❒ ${petik}${prefix}indo17${petik}   
│❒ ${petik}${prefix}indo18${petik}   
│❒ ${petik}${prefix}indo19${petik}   
│❒ ${petik}${prefix}indo20${petik}   
│❒ ${petik}${prefix}indo21${petik}   
│❒ ${petik}${prefix}indo22${petik}   
│❒ ${petik}${prefix}indo23${petik}   
│❒ ${petik}${prefix}indo24${petik}   
╰❒ ${petik}${prefix}indo25${petik} 
`
}

const storagemenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *STORAGE MENU*
├◪
│❒ ${petik}${prefix}readmore${petik}  
│❒ ${petik}${prefix}chatlist${petik}  
│❒ ${petik}${prefix}addsticker${petik}  
│❒ ${petik}${prefix}addvn${petik}  
│❒ ${petik}${prefix}getvn${petik}  
│❒ ${petik}${prefix}getsticker${petik}  
│❒ ${petik}${prefix}liststicker${petik}  
│❒ ${petik}${prefix}listvn${petik}  
│❒ ${petik}${prefix}addimage${petik}  
│❒ ${petik}${prefix}getimage${petik}  
│❒ ${petik}${prefix}imagelist${petik} 
│❒ ${petik}${prefix}addcmd${petik} 
│❒ ${petik}${prefix}listcmd${petik} 
│❒ ${petik}${prefix}delcmd${petik}  
│❒ ${petik}${prefix}addvideo${petik}  
│❒ ${petik}${prefix}getvideo${petik}  
╰❒ ${petik}${prefix}listvideo${petik} 
`
}

const cekmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *CHECK MENU*
├◪
│❒ ${petik}${prefix}gantengcek${petik}  
│❒ ${petik}${prefix}cantikcek${petik}  
│❒ ${petik}${prefix}jelekcek${petik}  
│❒ ${petik}${prefix}goblokcek${petik}  
│❒ ${petik}${prefix}begocek${petik}  
│❒ ${petik}${prefix}pintercek${petik}  
│❒ ${petik}${prefix}jagocek${petik}  
│❒ ${petik}${prefix}nolepcek${petik}  
│❒ ${petik}${prefix}babicek${petik}  
│❒ ${petik}${prefix}bebancek${petik}  
│❒ ${petik}${prefix}baikcek${petik}  
│❒ ${petik}${prefix}jahatcek${petik}  
│❒ ${petik}${prefix}anjingcek${petik}  
│❒ ${petik}${prefix}haramcek${petik}  
│❒ ${petik}${prefix}kontolcek${petik}  
│❒ ${petik}${prefix}pakboycek${petik}  
│❒ ${petik}${prefix}pakgirlcek${petik}  
│❒ ${petik}${prefix}sangecek${petik}  
╰❒ ${petik}${prefix}bapercek${petik} 
`
}

const tagmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *TAG MENU*
├◪
│❒ ${petik}${prefix}ganteng${petik}  
│❒ ${petik}${prefix}cantik${petik}  
│❒ ${petik}${prefix}jelek${petik}  
│❒ ${petik}${prefix}goblok${petik}  
│❒ ${petik}${prefix}bego${petik}  
│❒ ${petik}${prefix}pinter${petik}  
│❒ ${petik}${prefix}jago${petik}  
│❒ ${petik}${prefix}babi${petik}  
│❒ ${petik}${prefix}beban${petik}  
│❒ ${petik}${prefix}baik${petik}  
│❒ ${petik}${prefix}jahat${petik}  
│❒ ${petik}${prefix}anjing${petik}  
│❒ ${petik}${prefix}monyet${petik}  
│❒ ${petik}${prefix}haram${petik}  
│❒ ${petik}${prefix}kontol${petik}  
│❒ ${petik}${prefix}pakboy${petik}  
│❒ ${petik}${prefix}pakgirl${petik}  
│❒ ${petik}${prefix}sadboy${petik}  
│❒ ${petik}${prefix}sadgirl${petik}  
│❒ ${petik}${prefix}wibu${petik}  
│❒ ${petik}${prefix}nolep${petik}  
╰❒ ${petik}${prefix}hebat${petik} 
`
}

const gamemenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *GAME MENU*
├◪
│❒ ${petik}${prefix}slot${petik}  
│❒ ${petik}${prefix}simi${petik}  
│❒ ${petik}${prefix}jumlah${petik}   
│❒ ${petik}${prefix}tebakgambar${petik}  
│❒ ${petik}${prefix}nickff${petik}  
│❒ ${petik}${prefix}kapankah${petik}  
│❒ ${petik}${prefix}apakah${petik}  
│❒ ${petik}${prefix}ramalnomer${petik}   
│❒ ${petik}${prefix}ramalcinta${petik}   
│❒ ${petik}${prefix}jodohbali${petik}   
│❒ ${petik}${prefix}ramalnikah${petik}   
│❒ ${petik}${prefix}taksirmimpi${petik}   
│❒ ${petik}${prefix}suit${petik}
│❒ ${petik}${prefix}tictactoe${petik}
│❒ ${petik}${prefix}gelud${petik}                     
│❒ ${petik}${prefix}boomtext${petik}  
│❒ ${petik}${prefix}holoh${petik}  
│❒ ${petik}${prefix}heleh${petik}  
│❒ ${petik}${prefix}huluh${petik}  
│❒ ${petik}${prefix}hilih${petik}  
│❒ ${petik}${prefix}halah${petik}   
│❒ ${petik}${prefix}kapital${petik}  
│❒ ${petik}${prefix}textfont${petik}  
│❒ ${petik}${prefix}tebak${petik}  
│❒ ${petik}${prefix}oxo${petik}  
│❒ ${petik}${prefix}pesan${petik}  
│❒ ${petik}${prefix}tebakkimia${petik}  
│❒ ${petik}${prefix}tebaklirik${petik} 
│❒ ${petik}${prefix}tebakin1${petik}  
╰❒ ${petik}${prefix}tebakin2${petik} 
`
}

const randomtextmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *RANDOM TEXT*
├◪
│❒ ${petik}${prefix}quotes2${petik}  
│❒ ${petik}${prefix}grubwa${petik}  
│❒ ${petik}${prefix}brainly${petik}  
│❒ ${petik}${prefix}quotes1${petik}  
│❒ ${petik}${prefix}kusonime${petik}  
│❒ ${petik}${prefix}renungan${petik}  
│❒ ${petik}${prefix}samehadaku${petik}  
│❒ ${petik}${prefix}infonomer${petik}  
│❒ ${petik}${prefix}jadwaltv${petik}  
│❒ ${petik}${prefix}tvjadwal${petik}  
│❒ ${petik}${prefix}fml${petik}  
│❒ ${petik}${prefix}cinta${petik}  
│❒ ${petik}${prefix}resepmasakan${petik}  
│❒ ${petik}${prefix}cersex${petik}  
│❒ ${petik}${prefix}cerpen${petik}  
│❒ ${petik}${prefix}jadwalsholat${petik}  
│❒ ${petik}${prefix}pantun${petik}  
│❒ ${petik}${prefix}cuaca${petik}  
│❒ ${petik}${prefix}namaninja${petik}  
│❒ ${petik}${prefix}fake${petik}   
│❒ ${petik}${prefix}spamemail${petik}  
│❒ ${petik}${prefix}quotes${petik}  
│❒ ${petik}${prefix}quotesnime${petik}  
│❒ ${petik}${prefix}kbbilazimedia${petik}  
│❒ ${petik}${prefix}covid${petik}  
│❒ ${petik}${prefix}wikiid${petik}  
│❒ ${petik}${prefix}covidid${petik}  
│❒ ${petik}${prefix}kbbi${petik}  
│❒ ${petik}${prefix}infogempa${petik}  
│❒ ${petik}${prefix}randomquran${petik}  
│❒ ${petik}${prefix}kisanabi${petik}  
│❒ ${petik}${prefix}artinama${petik}  
│❒ ${petik}${prefix}artimimpi${petik}  
│❒ ${petik}${prefix}artijadian${petik}  
│❒ ${petik}${prefix}chord${petik}  
╰❒ ${petik}${prefix}lirik${petik} 
`
}

const fastmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *FAST MENU*
├◪
│❒ ${petik}${prefix}fb${petik}  
│❒ ${petik}${prefix}tts${petik}  
│❒ ${petik}${prefix}steam${petik}  
│❒ ${petik}${prefix}stalktwit${petik}  
│❒ ${petik}${prefix}stalkgithub${petik}   
│❒ ${petik}${prefix}randomhusbu${petik}
│❒ ${petik}${prefix}pinterest${petik}    
│❒ ${petik}${prefix}pinterest2${petik}  
│❒ ${petik}${prefix}randomwaifu${petik}  
│❒ ${petik}${prefix}randomwaifu1${petik}  
│❒ ${petik}${prefix}stalkig${petik}  
│❒ ${petik}${prefix}estetikpic${petik}  
│❒ ${petik}${prefix}memeindo${petik}  
│❒ ${petik}${prefix}darkjokes${petik}  
│❒ ${petik}${prefix}urlshort${petik}  
│❒ ${petik}${prefix}shortener${petik}  
│❒ ${petik}${prefix}fox${petik}  
│❒ ${petik}${prefix}dog${petik}  
│❒ ${petik}${prefix}cat${petik}  
│❒ ${petik}${prefix}panda${petik}  
│❒ ${petik}${prefix}panda1${petik}  
│❒ ${petik}${prefix}bird${petik}  
│❒ ${petik}${prefix}koala${petik}  
│❒ ${petik}${prefix}meme${petik}    
│❒ ${petik}${prefix}ngakak${petik}  
│❒ ${petik}${prefix}pin${petik}   
│❒ ${petik}${prefix}foto${petik}   
│❒ ${petik}${prefix}bts${petik}  
│❒ ${petik}${prefix}exo${petik}  
│❒ ${petik}${prefix}blackpink${petik}  
│❒ ${petik}${prefix}manga1${petik}  
│❒ ${petik}${prefix}character${petik}  
╰❒ ${petik}${prefix}bug${petik} 
`
}

const sertifikatmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


*MAINTENANCE*

╭─❒ *SERTIFIKAT MENU*
├◪
│❒ ${petik}${prefix}ffserti${petik}   
│❒ ${petik}${prefix}ffserti2${petik}  
│❒ ${petik}${prefix}ffserti3${petik}  
│❒ ${petik}${prefix}ffserti4${petik}  
│❒ ${petik}${prefix}ffserti5${petik}  
│❒ ${petik}${prefix}pubgserti${petik}  
│❒ ${petik}${prefix}pubgserti2${petik}  
│❒ ${petik}${prefix}pubgserti3${petik}  
│❒ ${petik}${prefix}pubgserti4${petik}  
│❒ ${petik}${prefix}pubgserti5${petik}  
│❒ ${petik}${prefix}mlserti${petik}  
│❒ ${petik}${prefix}mlserti2${petik}  
│❒ ${petik}${prefix}mlserti3${petik}  
│❒ ${petik}${prefix}mlserti4${petik}  
╰❒ ${petik}${prefix}mlserti5${petik} 
`
}

const ownermenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *OWNER MENU*
├◪
│❒ ${petik}${prefix}dellprem${petik}   
│❒ ${petik}${prefix}addprem${petik}  
│❒ ${petik}${prefix}clearall${petik}  
│❒ ${petik}${prefix}bc${petik}  
│❒ ${petik}${prefix}bcsticker${petik}  
│❒ ${petik}${prefix}bcvideo${petik} 
│❒ ${petik}${prefix}bcaudio${petik}  
│❒ ${petik}${prefix}bcgif${petik}  
│❒ ${petik}${prefix}owner${petik}  
│❒ ${petik}${prefix}author${petik}  
│❒ ${petik}${prefix}setthum${petik}  
│❒ ${petik}${prefix}setpp${petik}  
│❒ ${petik}${prefix}setprefix${petik}  
│❒ ${petik}${prefix}setreply${petik}  
│❒ ${petik}${prefix}> code${petik}  
│❒ ${petik}${prefix}=> code${petik}  
╰❒ ${petik}${prefix}$ code${petik} 
`
}

const makermenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *MAKER MENU*
├◪
│❒ ${petik}${prefix}emoji${petik}  
│❒ ${petik}${prefix}neon1${petik}  
│❒ ${petik}${prefix}text3d${petik}  
│❒ ${petik}${prefix}galaxy${petik}  
│❒ ${petik}${prefix}gaming${petik}  
│❒ ${petik}${prefix}colors${petik}  
│❒ ${petik}${prefix}kling${petik}  
│❒ ${petik}${prefix}ttp4${petik}  
│❒ ${petik}${prefix}ttp3${petik}  
│❒ ${petik}${prefix}ttp2${petik}  
│❒ ${petik}${prefix}ttp1${petik}  
│❒ ${petik}${prefix}attp${petik} 
│❒ ${petik}${prefix}sticker${petik}  
│❒ ${petik}${prefix}stickergif${petik} 
│❒ ${petik}${prefix}removebg${petik}   
│❒ ${petik}${prefix}tahta${petik} 
│❒ ${petik}${prefix}wall${petik} 
│❒ ${petik}${prefix}neon2${petik} 
│❒ ${petik}${prefix}wolf${petik} 
│❒ ${petik}${prefix}tfire${petik} 
│❒ ${petik}${prefix}ytgold${petik} 
│❒ ${petik}${prefix}ytsilver${petik} 
│❒ ${petik}${prefix}t3d${petik} 
│❒ ${petik}${prefix}logoa${petik} 
│❒ ${petik}${prefix}pornhub${petik} 
│❒ ${petik}${prefix}marvel${petik} 
│❒ ${petik}${prefix}leavest${petik} 
│❒ ${petik}${prefix}phcoment${petik} 
│❒ ${petik}${prefix}greenneon${petik}
│❒ ${petik}${prefix}advanceglow${petik}
│❒ ${petik}${prefix}futureneon${petik}
│❒ ${petik}${prefix}sandwriting${petik}
│❒ ${petik}${prefix}sandsummer${petik}
│❒ ${petik}${prefix}sandengraved${petik}
│❒ ${petik}${prefix}metaldark${petik}
│❒ ${petik}${prefix}neonlight${petik}
│❒ ${petik}${prefix}holographic${petik}
│❒ ${petik}${prefix}text1917${petik}
│❒ ${petik}${prefix}minion${petik}
│❒ ${petik}${prefix}deluxesilver${petik}
│❒ ${petik}${prefix}newyearcard${petik}
│❒ ${petik}${prefix}bloodfrosted${petik}
│❒ ${petik}${prefix}halloween${petik}
│❒ ${petik}${prefix}jokerlogo${petik}
│❒ ${petik}${prefix}fireworksparkle${petik}
│❒ ${petik}${prefix}natureleaves${petik}
│❒ ${petik}${prefix}bokeh${petik}
│❒ ${petik}${prefix}toxic${petik}
│❒ ${petik}${prefix}strawberry${petik}
│❒ ${petik}${prefix}box3d${petik}
│❒ ${petik}${prefix}roadwarning${petik}
│❒ ${petik}${prefix}breakwall${petik}
│❒ ${petik}${prefix}icecold${petik}
│❒ ${petik}${prefix}luxury${petik}
│❒ ${petik}${prefix}cloud${petik}
│❒ ${petik}${prefix}summersand${petik}
│❒ ${petik}${prefix}horrorblood${petik}
${petik}│❒ ${prefix}wetglass
│❒ ${prefix}multicolor3d
│❒ ${prefix}watercolor
│❒ ${prefix}luxurygold
│❒ ${prefix}galaxywallpaper
│❒ ${prefix}lighttext
│❒ ${prefix}beautifulflower
│❒ ${prefix}puppycute
│❒ ${prefix}royaltext
│❒ ${prefix}heartshaped
│❒ ${prefix}birthdaycake
│❒ ${prefix}galaxystyle
│❒ ${prefix}hologram3d
│❒ ${prefix}glossychrome
│❒ ${prefix}greenbush
│❒ ${prefix}metallogo
│❒ ${prefix}noeltext
│❒ ${prefix}glittergold
│❒ ${prefix}textcake
│❒ ${prefix}starsnight
│❒ ${prefix}wooden3d
│❒ ${prefix}textbyname
│❒ ${prefix}writegalacy
│❒ ${prefix}galaxybat
│❒ ${prefix}snow3d
│❒ ${prefix}birthdayday
│❒ ${prefix}goldplaybutton
│❒ ${prefix}silverplaybutton
│❒ ${prefix}freefire${petik}
╰❒ ${petik}${prefix}thunder${petik}
`
}

const spesialmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *SPESIAL MENU*
├◪
│❒ ${petik}${prefix}randomwibu${petik}  
│❒ ${petik}${prefix}phkomen${petik}  
│❒ ${petik}${prefix}semoji${petik}  
│❒ ${petik}${prefix}jadian${petik}  
│❒ ${petik}${prefix}citacita${petik}  
│❒ ${petik}${prefix}laut${petik}  
│❒ ${petik}${prefix}darat${petik}  
│❒ ${petik}${prefix}udara${petik}  
│❒ ${petik}${prefix}fakta${petik}  
│❒ ${petik}${prefix}gcard${petik}  
│❒ ${petik}${prefix}ssweb${petik}  
│❒ ${petik}${prefix}katailham${petik}  
╰❒ ${petik}${prefix}randomwibu${petik} 
`
}
const quotesmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *QUOTES MENU*
├◪
│❒ ${petik}${prefix}katailham${petik}  
│❒ ${petik}${prefix}dare${petik}   
│❒ ${petik}${prefix}truth${petik}  
│❒ ${petik}${prefix}katabijak_lucu${petik}   
│❒ ${petik}${prefix}katacaklontong${petik}  
╰❒ ${petik}${prefix}katadilan${petik}  
`
}
const newsmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *NEWS MENU*
├◪
│❒ ${petik}${prefix}newsdetik${petik}  
│❒ ${petik}${prefix}newskompas${petik}   
│❒ ${petik}${prefix}newstribun${petik}  
╰❒ ${petik}${prefix}jalantikus${petik}  
`
}
const cecanmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *GACHA CECAN*
├◪
│❒ ${petik}${prefix}china${petik}  
│❒ ${petik}${prefix}indonesia${petik}  
│❒ ${petik}${prefix}malaysia${petik}  
│❒ ${petik}${prefix}thailand${petik}  
│❒ ${petik}${prefix}korea${petik} 
│❒ ${petik}${prefix}japan${petik} 
│❒ ${petik}${prefix}vietnam${petik}  
│❒ ${petik}${prefix}jenni${petik}  
│❒ ${petik}${prefix}jiso${petik}  
│❒ ${petik}${prefix}lisa${petik} 
╰❒ ${petik}${prefix}rose${petik} 
`
}
const coganmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *GACHA COGAN*
├◪
│❒ ${petik}${prefix}baekhyung${petik}  
│❒ ${petik}${prefix}dohkyungsoo${petik}  
│❒ ${petik}${prefix}huangzitao${petik}  
│❒ ${petik}${prefix}jhope${petik}  
│❒ ${petik}${prefix}jimin${petik} 
│❒ ${petik}${prefix}jungkook${petik} 
│❒ ${petik}${prefix}kimjondae${petik}  
│❒ ${petik}${prefix}kimjong${petik}  
│❒ ${petik}${prefix}kimjunmyeon${petik}  
│❒ ${petik}${prefix}kimminseok${petik} 
│❒ ${petik}${prefix}kimnanjoon${petik}  
│❒ ${petik}${prefix}kimseok${petik}  
│❒ ${petik}${prefix}kimtaehyung${petik}  
│❒ ${petik}${prefix}luhan${petik}  
│❒ ${petik}${prefix}ohsehun${petik} 
│❒ ${petik}${prefix}parkchanyeol${petik} 
│❒ ${petik}${prefix}suga${petik}  
╰❒ ${petik}${prefix}wuyifan${petik}  
`
}
const asupanmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *ASUPAN MENU*
├◪
${petik}│❒ ${prefix}rikagusriani 
│❒ ${prefix}ukhty 
│❒ ${prefix}santuy 
│❒ ${prefix}geayubi   
│❒ ${prefix}bocil
│❒ ${prefix}asupan
│❒ ${prefix}chika 
│❒ ${prefix}delvira 
│❒ ${prefix}ayu   
│❒ ${prefix}bunga
│❒ ${prefix}aura
│❒ ${prefix}nisa 
│❒ ${prefix}ziva 
│❒ ${prefix}yana   
│❒ ${prefix}viona
│❒ ${prefix}syania
│❒ ${prefix}riri   
│❒ ${prefix}syifa
│❒ ${prefix}mama_gina
│❒ ${prefix}alcakenya 
╰❒ ${prefix}mangayutri${petik}  
`
}
const nsfwmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *NSFW & SFW MENU*
├◪
│❒ ${petik}${prefix}ahegao${petik}
│❒ ${petik}${prefix}ass${petik} 
│❒ ${petik}${prefix}bdsm${petik} 
│❒ ${petik}${prefix}blowjob${petik} 
│❒ ${petik}${prefix}cuckold${petik}
│❒ ${petik}${prefix}cum${petik} 
│❒ ${petik}${prefix}ero${petik} 
│❒ ${petik}${prefix}femdom${petik} 
│❒ ${petik}${prefix}foot${petik} 
│❒ ${petik}${prefix}gangbang${petik} 
│❒ ${petik}${prefix}glasses${petik}
│❒ ${petik}${prefix}hentai${petik} 
│❒ ${petik}${prefix}hentai_gifs${petik} 
│❒ ${petik}${prefix}jahy${petik} 
│❒ ${petik}${prefix}manga${petik} 
│❒ ${petik}${prefix}masturbation${petik} 
│❒ ${petik}${prefix}neko${petik}
│❒ ${petik}${prefix}orgy${petik} 
│❒ ${petik}${prefix}panties${petik} 
│❒ ${petik}${prefix}pussy${petik} 
│❒ ${petik}${prefix}neko_sfw${petik} 
│❒ ${petik}${prefix}tentacles${petik} 
│❒ ${petik}${prefix}thighs${petik}
│❒ ${petik}${prefix}yuri${petik}
╰❒ ${petik}${prefix}zettai${petik} 
`
}

const animemenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *ANIME MENU*
├◪
│❒ ${petik}${prefix}anna${petik}
│❒ ${petik}${prefix}asuna_yuki${petik} 
│❒ ${petik}${prefix}ayuzawa${petik} 
│❒ ${petik}${prefix}chitoge${petik} 
│❒ ${petik}${prefix}emilia${petik}
│❒ ${petik}${prefix}erza${petik} 
│❒ ${petik}${prefix}hinata${petik} 
│❒ ${petik}${prefix}inori${petik} 
│❒ ${petik}${prefix}kaga_kouko${petik} 
│❒ ${petik}${prefix}kaori_miyazono${petik} 
│❒ ${petik}${prefix}kotori_minami${petik}
│❒ ${petik}${prefix}mikasa${petik} 
│❒ ${petik}${prefix}mio_akiyama${petik} 
│❒ ${petik}${prefix}mizore_sirayuki${petik} 
│❒ ${petik}${prefix}nakiri_alice${petik} 
│❒ ${petik}${prefix}naruto${petik} 
│❒ ${petik}${prefix}riyas_gremori${petik}
│❒ ${petik}${prefix}sakura${petik} 
│❒ ${petik}${prefix}sasuke${petik} 
│❒ ${petik}${prefix}sento_isuzu${petik} 
│❒ ${petik}${prefix}shana${petik} 
│❒ ${petik}${prefix}shiina${petik} 
│❒ ${petik}${prefix}shinka${petik}
│❒ ${petik}${prefix}winry${petik}
│❒ ${petik}${prefix}yukino${petik} 
│❒ ${petik}${prefix}yuzuki${petik} 
│❒ ${petik}${prefix}akame${petik}
│❒ ${petik}${prefix}luffy
│❒ ${prefix}zoro
│❒ ${prefix}sanji
│❒ ${prefix}ussop
│❒ ${prefix}minato
│❒ ${prefix}boruto
│❒ ${prefix}sarada
│❒ ${prefix}mitsuki
│❒ ${prefix}orochimaru
│❒ ${prefix}tsunade
│❒ ${prefix}kakashi
│❒ ${prefix}killua
│❒ ${prefix}rimuru
│❒ ${prefix}sagiri
│❒ ${prefix}natsu
│❒ ${prefix}tanjirou
│❒ ${prefix}loli${petik}
╰❒ ${petik}${prefix}mikosiba${petik}
`
}
const image_effect = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *IMAGE EFFECT*
├◪
${petik}│❒ ${prefix}trigger
│❒ ${prefix}gay
│❒ ${prefix}glass
│❒ ${prefix}passed
│❒ ${prefix}jail
│❒ ${prefix}comrade
│❒ ${prefix}hijau
│❒ ${prefix}biru
│❒ ${prefix}greyscale
│❒ ${prefix}invert
│❒ ${prefix}invert_greyscale
│❒ ${prefix}red
│❒ ${prefix}blurple
│❒ ${prefix}blurple2
│❒ ${prefix}wasted
│❒ ${prefix}pelangi
│❒ ${prefix}sepia
│❒ ${prefix}wanted
│❒ ${prefix}utatoo
│❒ ${prefix}unsharpen
│❒ ${prefix}thanos
│❒ ${prefix}sniper
│❒ ${prefix}sharpen
│❒ ${prefix}scary
│❒ ${prefix}rip
│❒ ${prefix}rejected
│❒ ${prefix}redple
│❒ ${prefix}posterize
│❒ ${prefix}ps4
│❒ ${prefix}pixelize
│❒ ${prefix}missionpassed
│❒ ${prefix}moustache
│❒ ${prefix}lookwhatkarenhave
│❒ ${prefix}instagram
│❒ ${prefix}glitch
│❒ ${prefix}frame
│❒ ${prefix}fire
│❒ ${prefix}distort
│❒ ${prefix}dictator
│❒ ${prefix}deepfry
│❒ ${prefix}ddungeon
│❒ ${prefix}circle
│❒ ${prefix}challenger
│❒ ${prefix}burn
│❒ ${prefix}brazzers
╰❒ ${prefix}beautiful${petik}  
`
}

const botxx = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`[❗] MODE BOTX TIDAK AKTIF\nKETIK *${prefix}botx*\nUNTUK MENGAKTIFKAN`
	}
const error = (prefix, command) => {
    return`[❗] ERROR SILAHKAN LAPORKAN KE OWNER. KETIK *${prefix}bug ${command}*\n[ *APIKEY UNFALID* ]`
    }
const info1 = () => { 
    return`🐳 = $200
🦈 = $121
🐬 = $104
🐋 = $94
🐟 = $87
🐠 = $79
🦐 = $62
🦑 = $34
🦀 = $17
🐚 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
  }
const info2 = () => { 
    return`🐔 = $200
🦃 = $121
🐿 = $104
🐐 = $94
🐏 = $87
🐖 = $79
🐑 = $62
🐎 = $34
🐺 = $17
🦩 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
}
const info3 = () => { 
    return`🦋 = $200
🕷 = $121
🐝 = $104
🐉 = $94
🦆 = $87
🦅 = $79
🕊 = $62
🐧 = $34
🐦 = $17
🦇 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
} 
const lvlnul = () => {
	return`*LEVELMU MASIH KOSONG*`
}
const levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`╭──❲  NAIK LEVEL  ❳
│❒ ${petik}Nama : ${pushname}${petik}  
│❒ ${petik}wa.me/${sender.split("@")[0]} 
│❒ ${petik}Xp : ${getLevelingXp(sender)}${petik}  
│❒ ${petik}Limit : +3${petik}   
│❒ ${petik}Level : ${getLevel} ⊱ ${getLevelingLevel(sender)}${petik}  
╰──❲  BOTZ  ❳`	
}
const islamicmenu = (boton, wit,wita,wib,kyun,tampilHarii, tampilTanggal, totalchat, UserZeeone, ucapannya, tampilWaktu , hitbot, speedbotz, sender, ownername,pushname, prefix, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, giid) => {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${wib}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya}
│◦➛${tampilWaktu}
│◦➛Day : ${tampilHarii}
└❏ Date : ${tampilTanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏  MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Owner : ${ownername}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hitbot}
│◦➛Group Chat : ${giid.length}
│◦➛Personal Chat : ${totalchat.length - giid.length}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed : ${speedbotz.toFixed(4)} Second${petik} 
${petik}│◦➛Runtime : ${kyun(boton)}${petik}
${petik}└❏ ${UserZeeone.length} users${petik}


╭─❒ *ISLAMIC MENU*
├◪ 
│❒ ${petik}${prefix}kisah_nabi${petik}  
│❒ ${petik}${prefix}ayatkursi${petik}  
│❒ ${petik}${prefix}tahlil${petik}  
│❒ ${petik}${prefix}wirid${petik}  
│❒ ${petik}${prefix}quran${petik}  
│❒ ${petik}${prefix}alquran${petik}  
│❒ ${petik}${prefix}alquranaudio${petik}  
│❒ ${petik}${prefix}hadits${petik}  
│❒ ${petik}${prefix}hadits2${petik}  
│❒ ${petik}${prefix}listsurah${petik}  
│❒ ${petik}${prefix}doa_harian${petik}  
│❒ ${petik}${prefix}niat_shalat${petik}  
╰❒ ${petik}${prefix}bacaan_shalat${petik}  

`
}


exports.helpmenu = helpmenu
exports.grupmenu = grupmenu
exports.stickmenu = stickmenu
exports.promenu = promenu
exports.downloadmenu = downloadmenu
exports.soundmenu = soundmenu
exports.pornmenu = pornmenu
exports.storagemenu = storagemenu
exports.cekmenu = cekmenu
exports.tagmenu = tagmenu
exports.gamemenu = gamemenu
exports.randomtextmenu = randomtextmenu
exports.fastmenu = fastmenu
exports.sertifikatmenu = sertifikatmenu
exports.ownermenu = ownermenu
exports.makermenu = makermenu
exports.spesialmenu = spesialmenu
exports.newsmenu = newsmenu
exports.cecanmenu = cecanmenu
exports.coganmenu = coganmenu
exports.asupanmenu = asupanmenu
exports.nsfwmenu = nsfwmenu
exports.animemenu = animemenu
exports.botxx = botxx
exports.info1 = info1
exports.info2 = info2
exports.info3 = info3
exports.lvlnul = lvlnul
exports.levelup = levelup
exports.image_effect = image_effect
exports.quotesmenu = quotesmenu
exports.islamicmenu = islamicmenu
