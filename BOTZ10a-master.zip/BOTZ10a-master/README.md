# ```BOTZ10 LAST```

<p align="center">
<img src="https://github.com/zeeoneofc/BOTZ10a/blob/master/image/Alphabot.jpg" alt="BOTZ10" width="128" height="128"/>
</p>

<p align="center">
<a href="https://github.com/zeeoneofc/followers"><img title="Followers" src="https://img.shields.io/github/followers/zeeoneofc?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/BOTZ10a/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/zeeoneofc/BOTZ10a?color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/BOTZ10a/network/members"><img title="Forks" src="https://img.shields.io/github/forks/zeeoneofc/BOTZ10a?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/BOTZ10a/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zeeoneofc/BOTZ10a?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/BOTZ10a"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/zeeoneofc/BOTZ10a/"><img title="Size" src="https://img.shields.io/github/repo-size/zeeoneofc/BOTZ10a?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fzeeoneofc%2FBOTZ10a&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/zeeoneofc/BOTZ10a/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>

<p align='center'>
<a href="https://github.com/zeeoneofc/BOTZ10a#TERMUX">Termux</a> •
<a href="https://github.com/zeeoneofc/BOTZ10a#HEROKU">Heroku</a> •
<a href="https://github.com/zeeoneofc/BOTZ10a#CHANGE-SESSION">Session</a><br>
<a href="https://github.com/zeeoneofc/BOTZ10a#SETTING">Setting</a> •
<a href="https://github.com/zeeoneofc/BOTZ10a#thanks-to">Thanks</a>     
</p>

-------

## `TERMUX`

1. Git clone this repo<br/>

```
> git clone https://github.com/zeeoneofc/BOTZ10a.git
> cd BOTZ10a
> npm i
```
2. Run<br/>

```
> npm start
```

## `HEROKU`

1. Add Buildpack<br/>

```
> nodeajs
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
```
2. Delpoy<br/>

[`Click Here For Tutorial`](https://youtu.be/_CP2_1Yqauo)<br>

3. Change Dyno<br/>

<p align="center">
  <a href="https://youtu.be/_CP2_1Yqauo"><img src="https://a.top4top.io/p_20888ybra1.jpg" />
</p>


## `CHANGE SESSION`

1. Put your session here<br/>

[`Click Here`](https://github.com/zeeoneofc/Alphabot7/blob/master/session.json#L1)

## `SETTING`

- Owner Number [`Here`](https://github.com/zeeoneofc/Alphabot7/blob/master/settings.json#L4)
- Owner Name [`Here`](https://github.com/zeeoneofc/Alphabot7/blob/master/settings.json#L13)
- Bot Name [`Here`](https://github.com/zeeoneofc/Alphabot7/blob/master/settings.json#L14)

## `THANKS TO`

- [`Nayla`]()
- [`Rynz`]()
- [`Loki Killers`]()
- [`Ara-Ara`]()
- [`All creator bot`]()

## ```COFFEE```

- [`SAWERIA`](https://saweria.co/zeeoneofc)


